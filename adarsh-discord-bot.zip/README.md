# Adarsh's Discord Bot

A Discord.py bot with a small invite website. The site includes an **Add to Discord** button and credits **Adarsh** as the maker.

## Features

- `/ping` — bot latency
- `/about` — creator and bot details
- `/warn`, `/warnings`, `/clearwarnings` — basic warning system
- `/timeout`, `/untimeout` — member timeouts
- `/kick`, `/ban` — moderation
- `/purge` — clear recent messages
- `/serverinfo`, `/userinfo` — information
- `/poll` — yes/no reaction poll
- `/health` — Render health-check endpoint

**Important:** warnings are stored in memory and reset whenever the Render service restarts. Use a database for persistent moderation records.

## 1. Create your Discord application

1. Open https://discord.com/developers/applications and create an application.
2. Open **Bot** and create/reset the bot token.
3. Copy the token and the **Application ID** from General Information.
4. In the Bot settings, enable **Server Members Intent** and **Message Content Intent** if you want the configured intents. Keep your token private.
5. Under OAuth2, the website generates the invite URL using your Application ID.

## 2. Deploy to Render

1. Upload this project to a GitHub repository.
2. In Render, create a new **Web Service** from that repository.
3. Render will detect `render.yaml`, or enter:
   - Build command: `pip install -r requirements.txt`
   - Start command: `python main.py`
4. Add environment variables in Render:
   - `DISCORD_TOKEN` — bot token
   - `DISCORD_CLIENT_ID` — Application ID
   - `PUBLIC_BASE_URL` — your Render URL, e.g. `https://adarsh-discord-bot.onrender.com`
5. Deploy. Open your Render URL and click **Add to Discord**.

## 3. Discord setup

- Invite the bot using the website button and select the server.
- Make sure the bot's role is above the roles it needs to moderate.
- Only members with the relevant Discord permissions can use moderation commands.
- Slash commands may take a short time to appear after the first deployment.

## Notes

- Never put your bot token in frontend code, GitHub, screenshots, or public messages.
- The invite button requests only the permissions used by the bot. Review permissions before authorizing.
- This is a starter project, not a production moderation platform. Add a database, audit logging, rate limits, and stronger role-policy checks before large-scale use.
