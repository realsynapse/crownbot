import os
import threading
from datetime import datetime, timezone

import discord
from discord import app_commands
from discord.ext import commands
from flask import Flask, render_template

# ---- Configuration ----
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "").strip()
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
BOT_MAKER = "Adarsh"

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
web = Flask(__name__)

# In-memory warning storage. Warnings reset when the process restarts.
# For persistent warnings, connect a database before using this in a large server.
warnings_store = {}


def invite_url():
    if not CLIENT_ID:
        return None
    permissions = discord.Permissions(
        view_channel=True,
        send_messages=True,
        read_message_history=True,
        embed_links=True,
        moderate_members=True,
        kick_members=True,
        ban_members=True,
        manage_messages=True,
    )
    return (
        "https://discord.com/oauth2/authorize"
        f"?client_id={CLIENT_ID}"
        f"&permissions={permissions.value}"
        "&scope=bot%20applications.commands"
    )


@web.route("/")
def home():
    return render_template(
        "index.html",
        maker=BOT_MAKER,
        invite_url=invite_url(),
        client_id=CLIENT_ID,
        year=datetime.now(timezone.utc).year,
    )


@web.route("/health")
def health():
    return {"status": "ok", "bot_ready": bot.is_ready()}, 200


async def sync_commands():
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} application commands.")
    except Exception as exc:
        print(f"Command sync failed: {exc}")


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    await sync_commands()


@bot.tree.command(name="ping", description="Check the bot's latency.")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    await interaction.response.send_message(
        f"🏓 Pong! **{latency} ms**", ephemeral=True
    )


@bot.tree.command(name="about", description="See who made this bot.")
async def about(interaction: discord.Interaction):
    embed = discord.Embed(
        title="About this bot",
        description="A multipurpose server helper with moderation tools.",
        color=discord.Color.blurple(),
    )
    embed.add_field(name="Made by", value=f"**{BOT_MAKER}**", inline=True)
    embed.add_field(name="Library", value="discord.py", inline=True)
    embed.set_footer(text="Built to help communities run smoothly.")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="warn", description="Give a member a warning.")
@app_commands.describe(member="Member to warn", reason="Why are they being warned?")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.checks.bot_has_permissions(send_messages=True)
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str):
    if member.bot:
        return await interaction.response.send_message(
            "Bots cannot be warned with this command.", ephemeral=True
        )
    key = (interaction.guild_id, member.id)
    warnings_store.setdefault(key, []).append({
        "reason": reason,
        "moderator": interaction.user.id,
        "time": datetime.now(timezone.utc).isoformat(),
    })
    count = len(warnings_store[key])
    embed = discord.Embed(
        title="⚠️ Member warned",
        description=f"{member.mention} has received a warning.",
        color=discord.Color.orange(),
    )
    embed.add_field(name="Reason", value=reason[:1024], inline=False)
    embed.add_field(name="Total warnings this session", value=str(count))
    embed.set_footer(text=f"Moderator: {interaction.user}")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="warnings", description="View a member's warnings.")
@app_commands.describe(member="Member whose warnings you want to view")
@app_commands.checks.has_permissions(moderate_members=True)
async def warnings(interaction: discord.Interaction, member: discord.Member):
    entries = warnings_store.get((interaction.guild_id, member.id), [])
    if not entries:
        return await interaction.response.send_message(
            f"{member.mention} has no warnings recorded in this session.",
            ephemeral=True,
        )
    lines = [
        f"**{i}.** {item['reason']} — <@{item['moderator']}>"
        for i, item in enumerate(entries[-10:], start=max(1, len(entries) - 9))
    ]
    embed = discord.Embed(
        title=f"Warnings for {member}",
        description="\n".join(lines)[:4000],
        color=discord.Color.orange(),
    )
    embed.set_footer(text=f"{len(entries)} total warning(s) in this session")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="clearwarnings", description="Clear a member's warnings.")
@app_commands.describe(member="Member whose warnings should be cleared")
@app_commands.checks.has_permissions(moderate_members=True)
async def clearwarnings(interaction: discord.Interaction, member: discord.Member):
    warnings_store.pop((interaction.guild_id, member.id), None)
    await interaction.response.send_message(
        f"Cleared recorded warnings for {member.mention}.", ephemeral=True
    )


@bot.tree.command(name="timeout", description="Temporarily timeout a member.")
@app_commands.describe(member="Member to timeout", minutes="Duration from 1 to 10080 minutes", reason="Reason")
@app_commands.checks.has_permissions(moderate_members=True)
async def timeout_member(
    interaction: discord.Interaction,
    member: discord.Member,
    minutes: app_commands.Range[int, 1, 10080],
    reason: str = "No reason provided",
):
    if member.top_role >= interaction.user.top_role and interaction.guild.owner_id != interaction.user.id:
        return await interaction.response.send_message(
            "You cannot timeout a member with an equal or higher role.", ephemeral=True
        )
    until = discord.utils.utcnow() + discord.timedelta(minutes=minutes) if hasattr(discord, "timedelta") else None
    # datetime.timedelta is used directly for compatibility.
    from datetime import timedelta
    await member.timeout(timedelta(minutes=minutes), reason=reason)
    await interaction.response.send_message(
        f"⏳ Timed out {member.mention} for **{minutes} minute(s)**.\nReason: {reason}"
    )


@bot.tree.command(name="untimeout", description="Remove a member's timeout.")
@app_commands.describe(member="Member to untimeout", reason="Reason")
@app_commands.checks.has_permissions(moderate_members=True)
async def untimeout_member(
    interaction: discord.Interaction,
    member: discord.Member,
    reason: str = "No reason provided",
):
    await member.timeout(None, reason=reason)
    await interaction.response.send_message(f"Timeout removed for {member.mention}.")


@bot.tree.command(name="kick", description="Kick a member from the server.")
@app_commands.describe(member="Member to kick", reason="Reason")
@app_commands.checks.has_permissions(kick_members=True)
async def kick_member(
    interaction: discord.Interaction,
    member: discord.Member,
    reason: str = "No reason provided",
):
    if member.top_role >= interaction.user.top_role and interaction.guild.owner_id != interaction.user.id:
        return await interaction.response.send_message(
            "You cannot kick a member with an equal or higher role.", ephemeral=True
        )
    await member.kick(reason=reason)
    await interaction.response.send_message(f"👢 Kicked **{member}**. Reason: {reason}")


@bot.tree.command(name="ban", description="Ban a member from the server.")
@app_commands.describe(member="Member to ban", reason="Reason")
@app_commands.checks.has_permissions(ban_members=True)
async def ban_member(
    interaction: discord.Interaction,
    member: discord.Member,
    reason: str = "No reason provided",
):
    if member.top_role >= interaction.user.top_role and interaction.guild.owner_id != interaction.user.id:
        return await interaction.response.send_message(
            "You cannot ban a member with an equal or higher role.", ephemeral=True
        )
    await member.ban(reason=reason)
    await interaction.response.send_message(f"🔨 Banned **{member}**. Reason: {reason}")


@bot.tree.command(name="purge", description="Delete recent messages in this channel.")
@app_commands.describe(amount="Number of messages to delete (1–100)")
@app_commands.checks.has_permissions(manage_messages=True)
async def purge(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    if not isinstance(interaction.channel, discord.TextChannel):
        return await interaction.response.send_message(
            "This command only works in text channels.", ephemeral=True
        )
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.followup.send(f"🧹 Deleted **{len(deleted)}** message(s).", ephemeral=True)


@bot.tree.command(name="serverinfo", description="Show information about this server.")
async def serverinfo(interaction: discord.Interaction):
    guild = interaction.guild
    embed = discord.Embed(title=guild.name, color=discord.Color.blurple())
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.add_field(name="Members", value=str(guild.member_count or "Unknown"))
    embed.add_field(name="Channels", value=str(len(guild.channels)))
    embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, style="D"))
    embed.set_footer(text=f"Server ID: {guild.id}")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="userinfo", description="Show information about a server member.")
@app_commands.describe(member="Member to inspect (defaults to you)")
async def userinfo(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user
    embed = discord.Embed(title=f"User info: {member}", color=discord.Color.blurple())
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="Display name", value=member.display_name, inline=True)
    embed.add_field(name="Account created", value=discord.utils.format_dt(member.created_at, style="D"), inline=False)
    if member.joined_at:
        embed.add_field(name="Joined server", value=discord.utils.format_dt(member.joined_at, style="D"), inline=False)
    embed.set_footer(text=f"User ID: {member.id}")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="poll", description="Create a simple yes/no poll.")
@app_commands.describe(question="What do you want to ask?")
async def poll(interaction: discord.Interaction, question: str):
    embed = discord.Embed(title="📊 Poll", description=question, color=discord.Color.blurple())
    embed.set_footer(text=f"Poll by {interaction.user.display_name}")
    await interaction.response.send_message(embed=embed)
    message = await interaction.original_response()
    await message.add_reaction("👍")
    await message.add_reaction("👎")


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        message = "You don't have the required server permission to use that command."
    elif isinstance(error, app_commands.BotMissingPermissions):
        message = "I am missing a permission needed for that action. Check my role and permissions."
    else:
        print(f"Command error: {error}")
        message = "Something went wrong while running that command."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)
    except discord.HTTPException:
        pass


def run_web():
    port = int(os.getenv("PORT", "10000"))
    web.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    threading.Thread(target=run_web, daemon=True).start()
    if not TOKEN:
        raise RuntimeError("Set DISCORD_TOKEN in your Render environment variables.")
    bot.run(TOKEN)
